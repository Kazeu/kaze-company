
V1.0.0
-Initial creation 

V1.0.1
-Added github repo
-Changed name of modpack